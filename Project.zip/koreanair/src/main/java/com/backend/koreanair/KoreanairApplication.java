package com.backend.koreanair;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KoreanairApplication {

	public static void main(String[] args) {
		SpringApplication.run(KoreanairApplication.class, args);
	}

}
